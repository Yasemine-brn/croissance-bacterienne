# croissance-bacterienne
Analyse de croissance de E. coli
